﻿#requires -version 5.1
<#
    Downloader.ps1
    GitHub 下载加速：镜像测速 + 多线程分块下载 + 断点文件合并。
#>

$script:CurlPath = Join-Path $env:SystemRoot 'System32\curl.exe'

$script:MirrorPrefixes = @(
    [pscustomobject]@{ Name = 'ghfast.top'; Prefix = 'https://ghfast.top/' }
    [pscustomobject]@{ Name = 'ghproxy.net'; Prefix = 'https://ghproxy.net/' }
    [pscustomobject]@{ Name = 'gh-proxy.com'; Prefix = 'https://gh-proxy.com/' }
    [pscustomobject]@{ Name = 'GitHub 直连'; Prefix = '' }
)

function Get-GitHubDownloadInfo {
    param([Parameter(Mandatory)][string]$Url)

    $text = $Url.Trim()
    if (-not $text) { throw '请输入 GitHub 下载链接' }
    if ($text -notmatch '^https?://') { $text = 'https://' + $text }

    $uri = $null
    try { $uri = [Uri]$text } catch { throw '链接格式不正确' }

    $allowed = @(
        'github.com',
        'www.github.com',
        'raw.githubusercontent.com',
        'codeload.github.com',
        'objects.githubusercontent.com',
        'gist.githubusercontent.com',
        'api.github.com'
    )
    if ($allowed -notcontains $uri.Host.ToLowerInvariant()) {
        throw '目前只支持 github.com / raw.githubusercontent.com / codeload.github.com 等 GitHub 链接'
    }

    $fileName = [System.IO.Path]::GetFileName($uri.AbsolutePath)
    $fileName = [Uri]::UnescapeDataString($fileName)
    if (-not $fileName) { $fileName = 'github-download' }
    $fileName = $fileName -replace '[\\/:*?"<>|]', '_'

    return [pscustomobject]@{
        Url      = $text
        Uri      = $uri
        FileName = $fileName
    }
}

function Measure-DownloadMirror {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Prefix,
        [int]$RangeBytes = 262144,
        [int]$TimeoutSeconds = 8
    )

    $testUrl = $Prefix + $Url
    $id = [Guid]::NewGuid().ToString('N')
    $headerFile = Join-Path $env:TEMP ('ghacc-h-' + $id + '.txt')
    $bodyFile = Join-Path $env:TEMP ('ghacc-b-' + $id + '.bin')

    $code = '000'
    $size = 0
    $speed = 0
    $time = 0
    try {
        $arguments = @(
            '-sS', '-L', '--max-time', [string]$TimeoutSeconds,
            '--range', "0-$($RangeBytes - 1)",
            '-D', $headerFile,
            '-o', $bodyFile,
            '-w', '%{http_code}|%{size_download}|%{speed_download}|%{time_total}',
            $testUrl
        )
        $output = & $script:CurlPath @arguments 2>$null
        if ($output) {
            $parts = ([string]$output).Trim() -split '\|'
            if ($parts.Count -ge 4) {
                $code = $parts[0]
                $size = [double]$parts[1]
                $speed = [double]$parts[2]
                $time = [double]$parts[3]
            }
        }

        $rangeSupported = $false
        $totalSize = [long]0
        if (Test-Path -LiteralPath $headerFile) {
            $headers = [System.IO.File]::ReadAllText($headerFile)
            if ($headers -match '(?im)^Content-Range:\s*bytes\s+\d+-\d+/(\d+)') {
                $rangeSupported = $true
                $totalSize = [long]$Matches[1]
            } elseif ($headers -match '(?im)^Content-Length:\s*(\d+)') {
                $totalSize = [long]$Matches[1]
            }
        }

        if ($code -eq '206') { $rangeSupported = $true }

        $ok = ($code -match '^2\d\d$')
        return [pscustomobject]@{
            Name           = if ($Prefix) { $Prefix.TrimEnd('/').Replace('https://', '') } else { 'GitHub 直连' }
            Prefix         = $Prefix
            HttpCode       = $code
            SampleBytes    = [long]$size
            SpeedBytes     = [double]$speed
            TimeSeconds    = [double]$time
            RangeSupported = $rangeSupported
            TotalSize      = $totalSize
            Ok             = $ok
            Url            = $testUrl
        }
    } finally {
        if (Test-Path -LiteralPath $headerFile) { Remove-Item -LiteralPath $headerFile -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $bodyFile) { Remove-Item -LiteralPath $bodyFile -Force -ErrorAction SilentlyContinue }
    }
}

function Measure-AllDownloadMirrors {
    param(
        [Parameter(Mandatory)][string]$Url,
        [int]$RangeBytes = 262144,
        [int]$TimeoutSeconds = 8
    )

    $results = New-Object System.Collections.Generic.List[object]
    foreach ($mirror in $script:MirrorPrefixes) {
        $result = Measure-DownloadMirror -Url $Url -Prefix $mirror.Prefix -RangeBytes $RangeBytes -TimeoutSeconds $TimeoutSeconds
        $result | Add-Member -NotePropertyName MirrorName -NotePropertyValue $mirror.Name -Force
        $results.Add($result)
    }
    return $results
}

function Start-DownloadJob {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Prefix,
        [long]$TotalSize,
        [Parameter(Mandatory)][string]$Target,
        [int]$PartCount = 4
    )

    if ($TotalSize -le 0) { throw '无法获取文件大小' }
    if ($PartCount -lt 1) { $PartCount = 1 }

    $tempDir = Join-Path $env:TEMP ('ghacc-dl-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

    $partSize = [long][Math]::Ceiling($TotalSize / $PartCount)
    $parts = New-Object System.Collections.Generic.List[object]

    for ($i = 0; $i -lt $PartCount; $i++) {
        $start = [long]$i * $partSize
        if ($start -ge $TotalSize) { continue }
        $end = [long][Math]::Min($start + $partSize - 1, $TotalSize - 1)
        $expected = $end - $start + 1
        $path = Join-Path $tempDir ('part{0:D2}' -f $i)

        $arguments = @(
            '-sS', '-L', '--fail', '--retry', '3', '--retry-delay', '2',
            '--connect-timeout', '30', '--max-time', '3600',
            '--range', "$start-$end",
            '-o', $path,
            ($Prefix + $Url)
        )
        $process = Start-Process -FilePath $script:CurlPath -ArgumentList $arguments -PassThru -WindowStyle Hidden
        $parts.Add([pscustomobject]@{
                Index    = $i
                Start    = $start
                End      = $end
                Expected = $expected
                Path     = $path
                Process  = $process
            })
    }

    return [pscustomobject]@{
        Url      = $Url
        Prefix   = $Prefix
        Total    = $TotalSize
        Target   = $Target
        TempDir  = $tempDir
        Parts    = $parts.ToArray()
        Single   = $false
        Process  = $null
        Started  = Get-Date
    }
}

function Start-SingleDownloadJob {
    param(
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Prefix,
        [long]$TotalSize,
        [Parameter(Mandatory)][string]$Target
    )

    $tempDir = Join-Path $env:TEMP ('ghacc-dl-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    $tempFile = Join-Path $tempDir 'download.bin'

    $arguments = @(
        '-sS', '-L', '--fail', '--retry', '3', '--retry-delay', '2',
        '--connect-timeout', '30', '--max-time', '7200',
        '-o', $tempFile,
        ($Prefix + $Url)
    )
    $process = Start-Process -FilePath $script:CurlPath -ArgumentList $arguments -PassThru -WindowStyle Hidden

    return [pscustomobject]@{
        Url     = $Url
        Prefix  = $Prefix
        Total   = $TotalSize
        Target  = $Target
        TempDir = $tempDir
        Parts   = @()
        Single  = $true
        Process = $process
        TempFile= $tempFile
        Started = Get-Date
    }
}

function Get-DownloadJobBytes {
    param([Parameter(Mandatory)]$Job)

    if ($Job.Single) {
        if (Test-Path -LiteralPath $Job.TempFile) { return [long](Get-Item -LiteralPath $Job.TempFile).Length }
        return [long]0
    }

    $sum = [long]0
    foreach ($part in $Job.Parts) {
        if (Test-Path -LiteralPath $part.Path) {
            $length = (Get-Item -LiteralPath $part.Path).Length
            if ($length -gt $part.Expected) { $length = $part.Expected }
            $sum += $length
        }
    }
    return $sum
}

function Test-DownloadJobComplete {
    param([Parameter(Mandatory)]$Job)

    if ($Job.Single) { return $Job.Process.HasExited }
    foreach ($part in $Job.Parts) {
        if (-not $part.Process.HasExited) { return $false }
    }
    return $true
}

function Complete-DownloadJob {
    param([Parameter(Mandatory)]$Job)

    if (-not $Job.Single) {
        foreach ($part in $Job.Parts) {
            if (-not $part.Process.HasExited) { throw '仍有下载线程在运行' }
            if ($part.Process.ExitCode -ne 0) { throw "分块 $($part.Index) 下载失败（curl 退出码 $($part.Process.ExitCode)）" }
            if (-not (Test-Path -LiteralPath $part.Path)) { throw "分块 $($part.Index) 文件丢失" }
            $length = (Get-Item -LiteralPath $part.Path).Length
            if ($length -ne $part.Expected) { throw "分块 $($part.Index) 大小不正确：$length / $($part.Expected)" }
        }
    } else {
        if (-not $Job.Process.HasExited) { throw '下载尚未结束' }
        if ($Job.Process.ExitCode -ne 0) { throw "下载失败（curl 退出码 $($Job.Process.ExitCode)）" }
    }

    $targetDir = Split-Path -Parent $Job.Target
    if ($targetDir -and -not (Test-Path -LiteralPath $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    $tempOutput = $Job.Target + '.ghacc-part'
    if (Test-Path -LiteralPath $tempOutput) { Remove-Item -LiteralPath $tempOutput -Force }

    if ($Job.Single) {
        Move-Item -LiteralPath $Job.TempFile -Destination $tempOutput -Force
    } else {
        $output = [System.IO.File]::Create($tempOutput)
        try {
            foreach ($part in ($Job.Parts | Sort-Object Index)) {
                $input = [System.IO.File]::OpenRead($part.Path)
                try { $input.CopyTo($output) } finally { $input.Dispose() }
            }
        } finally {
            $output.Dispose()
        }
    }

    $finalSize = (Get-Item -LiteralPath $tempOutput).Length
    if ($Job.Total -gt 0 -and $finalSize -ne $Job.Total) {
        throw "下载完成但大小不一致：$finalSize / $($Job.Total)"
    }

    if (Test-Path -LiteralPath $Job.Target) { Remove-Item -LiteralPath $Job.Target -Force }
    Move-Item -LiteralPath $tempOutput -Destination $Job.Target -Force
    Remove-Item -LiteralPath $Job.TempDir -Recurse -Force -ErrorAction SilentlyContinue
    return [pscustomobject]@{ Path = $Job.Target; Size = $finalSize }
}

function Stop-DownloadJob {
    param([Parameter(Mandatory)]$Job)

    try {
        if ($Job.Single) {
            if ($Job.Process -and -not $Job.Process.HasExited) { $Job.Process.Kill() }
        } else {
            foreach ($part in $Job.Parts) {
                if ($part.Process -and -not $part.Process.HasExited) { $part.Process.Kill() }
            }
        }
    } catch { }

    Start-Sleep -Milliseconds 300
    if ($Job.TempDir -and (Test-Path -LiteralPath $Job.TempDir)) {
        Remove-Item -LiteralPath $Job.TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
