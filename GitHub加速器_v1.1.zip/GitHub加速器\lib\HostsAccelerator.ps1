﻿#requires -version 5.1
<#
    HostsAccelerator.ps1
    GitHub 网页访问加速：获取公共 hosts 数据，逐 IP 验证 TLS/延迟，写入 hosts，可一键还原。
#>

$script:HostsSourceUrl = 'https://raw.hellogithub.com/hosts'
$script:HostsStartMarker = '# >>> GitHub Accelerator >>>'
$script:HostsEndMarker = '# <<< GitHub Accelerator <<<'
$script:CurlPath = Join-Path $env:SystemRoot 'System32\curl.exe'

$script:HostsDomains = @(
    'github.com'
    'api.github.com'
    'raw.githubusercontent.com'
    'gist.github.com'
    'gist.githubusercontent.com'
    'codeload.github.com'
    'objects.githubusercontent.com'
    'avatars.githubusercontent.com'
    'camo.githubusercontent.com'
    'media.githubusercontent.com'
    'user-images.githubusercontent.com'
    'private-user-images.githubusercontent.com'
    'github.githubassets.com'
    'github.global.ssl.fastly.net'
    'desktop.githubusercontent.com'
    'central.github.com'
    'collector.github.com'
)

function Test-IsAdministrator {
    try {
        $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

function Get-HostsFilePath {
    return (Join-Path $env:SystemRoot 'System32\drivers\etc\hosts')
}

function Get-GitHubHostsSource {
    param([int]$TimeoutSeconds = 12)

    $temp = Join-Path $env:TEMP ('ghacc-hosts-' + [Guid]::NewGuid().ToString('N') + '.txt')
    try {
        $arguments = @('-sS', '-L', '--max-time', [string]$TimeoutSeconds, '-o', $temp, $script:HostsSourceUrl)
        & $script:CurlPath @arguments 2>$null | Out-Null
        if (-not (Test-Path -LiteralPath $temp)) { throw '无法获取 GitHub hosts 数据' }
        $content = [System.IO.File]::ReadAllText($temp)
        if (-not $content.Trim()) { throw 'GitHub hosts 数据为空' }
        return $content
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
}

function ConvertTo-GitHubHostCandidates {
    param([Parameter(Mandatory)][string]$Text)

    $candidates = New-Object System.Collections.Generic.List[object]
    $seen = New-Object 'System.Collections.Generic.HashSet[string]'

    foreach ($line in ($Text -split "`r?`n")) {
        if ($line -match '(?i)#\s*timeout') { continue }
        if ($line -match '^\s*#') { continue }
        if ($line -notmatch '^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+([A-Za-z0-9][A-Za-z0-9\.\-]+)') { continue }

        $ip = $Matches[1]
        $domain = $Matches[2].ToLowerInvariant()
        if ($ip -eq '0.0.0.0' -or $ip -like '127.*') { continue }
        if ($script:HostsDomains -notcontains $domain) { continue }

        $key = "$domain|$ip"
        if (-not $seen.Add($key)) { continue }
        $candidates.Add([pscustomobject]@{ Domain = $domain; IP = $ip })
    }

    return $candidates
}

function Test-GitHubHostEntry {
    param(
        [Parameter(Mandatory)][string]$Domain,
        [Parameter(Mandatory)][string]$IP,
        [int]$TimeoutSeconds = 5
    )

    $temp = Join-Path $env:TEMP ('ghacc-probe-' + [Guid]::NewGuid().ToString('N') + '.bin')
    try {
        $arguments = @(
            '-sS', '-o', $temp, '--max-time', [string]$TimeoutSeconds,
            '--range', '0-1023',
            '--resolve', "$($Domain):443:$($IP)",
            '-w', '%{http_code}|%{time_total}',
            "https://$Domain/"
        )
        $output = & $script:CurlPath @arguments 2>$null
        $exit = $LASTEXITCODE
        if ($exit -ne 0 -or -not $output) {
            return [pscustomobject]@{ Domain = $Domain; IP = $IP; Ok = $false; HttpCode = '000'; LatencyMs = 0; Error = "curl $exit" }
        }

        $parts = ([string]$output).Trim() -split '\|'
        $code = $parts[0]
        $seconds = 0.0
        if ($parts.Count -ge 2) { $seconds = [double]$parts[1] }
        $numeric = 0
        $ok = [int]::TryParse($code, [ref]$numeric) -and $numeric -ge 200 -and $numeric -lt 500

        return [pscustomobject]@{
            Domain    = $Domain
            IP        = $IP
            Ok        = $ok
            HttpCode  = $code
            LatencyMs = [int][Math]::Round($seconds * 1000)
            Error     = ''
        }
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
}

function Get-BestGitHubHosts {
    param(
        [string]$SourceText = '',
        [object[]]$ExtraEntries = @()
    )

    if (-not $SourceText) { $SourceText = Get-GitHubHostsSource }
    $candidates = New-Object System.Collections.Generic.List[object]
    $seen = New-Object 'System.Collections.Generic.HashSet[string]'

    foreach ($entry in @($ExtraEntries)) {
        if ($null -eq $entry) { continue }
        $domain = [string]$entry.Domain
        $ip = [string]$entry.IP
        if ($script:HostsDomains -notcontains $domain) { continue }
        $key = "$domain|$ip"
        if ($seen.Add($key)) {
            $candidates.Add([pscustomobject]@{ Domain = $domain; IP = $ip; Current = $true })
        }
    }

    foreach ($candidate in @(ConvertTo-GitHubHostCandidates -Text $SourceText)) {
        $key = "$($candidate.Domain)|$($candidate.IP)"
        if ($seen.Add($key)) {
            $candidates.Add([pscustomobject]@{ Domain = $candidate.Domain; IP = $candidate.IP; Current = $false })
        }
    }

    if ($candidates.Count -eq 0) { throw 'hosts 数据中没有可用的 GitHub 域名' }

    $best = New-Object System.Collections.Generic.List[object]
    $results = New-Object System.Collections.Generic.List[object]

    foreach ($group in ($candidates | Group-Object Domain)) {
        $domain = $group.Name
        $tested = @()
        foreach ($candidate in ($group.Group | Select-Object -First 4)) {
            $result = Test-GitHubHostEntry -Domain $domain -IP $candidate.IP
            $tested += $result
        }
        $results.Add([pscustomobject]@{ Domain = $domain; Tested = $tested })

        $winner = $tested | Where-Object { $_.Ok } | Sort-Object LatencyMs | Select-Object -First 1
        if ($winner) {
            $best.Add([pscustomobject]@{
                    Domain    = $domain
                    IP        = $winner.IP
                    LatencyMs = $winner.LatencyMs
                    HttpCode  = $winner.HttpCode
                })
        }
    }

    return [pscustomobject]@{
        Entries = $best.ToArray()
        Details = $results.ToArray()
        Source  = $SourceText
    }
}

function Get-AppliedGitHubHosts {
    param([string]$Path = (Get-HostsFilePath))

    $entries = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path -LiteralPath $Path)) { return $entries.ToArray() }

    $content = [System.IO.File]::ReadAllText($Path)
    $pattern = '(?ms)' + [regex]::Escape($script:HostsStartMarker) + '(.*?)' + [regex]::Escape($script:HostsEndMarker)
    $match = [regex]::Match($content, $pattern)
    if (-not $match.Success) { return $entries.ToArray() }

    foreach ($line in ($match.Groups[1].Value -split "`r?`n")) {
        if ($line -match '^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+([A-Za-z0-9][A-Za-z0-9\.\-]+)') {
            $entries.Add([pscustomobject]@{ Domain = $Matches[2].ToLowerInvariant(); IP = $Matches[1] })
        }
    }
    return $entries.ToArray()
}

function Get-HostsBlockText {
    param([object[]]$Entries, [string]$Source = '')

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add($script:HostsStartMarker)
    $lines.Add('# Generated: ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
    if ($Source) { $lines.Add('# Source: ' + $Source) }
    foreach ($entry in ($Entries | Sort-Object Domain)) {
        $lines.Add(('{0,-16} {1}' -f $entry.IP, $entry.Domain))
    }
    $lines.Add($script:HostsEndMarker)
    return ($lines -join "`r`n")
}

function Test-HostsFileHasBlock {
    param([string]$Path = (Get-HostsFilePath))

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $content = [System.IO.File]::ReadAllText($Path)
    return $content.Contains($script:HostsStartMarker)
}

function Backup-HostsFile {
    param(
        [string]$Path = (Get-HostsFilePath),
        [string]$BackupDirectory = (Join-Path $PSScriptRoot '..\output')
    )

    if (-not (Test-Path -LiteralPath $BackupDirectory)) {
        New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
    }
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $backup = Join-Path $BackupDirectory ("hosts-backup-$stamp.txt")
    Copy-Item -LiteralPath $Path -Destination $backup -Force
    return $backup
}

function Clear-DnsCache {
    try { & ipconfig.exe /flushdns 2>$null | Out-Null } catch { }
}

function Set-GitHubHostsEntries {
    param(
        [Parameter(Mandatory)][object[]]$Entries,
        [string]$Path = (Get-HostsFilePath),
        [string]$BackupDirectory = (Join-Path $PSScriptRoot '..\output'),
        [string]$Source = '',
        [switch]$SkipAdminCheck
    )

    if (-not $SkipAdminCheck -and -not (Test-IsAdministrator)) {
        throw '修改 hosts 需要管理员权限，请以管理员身份运行本工具'
    }
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到 hosts 文件：$Path" }

    $backup = Backup-HostsFile -Path $Path -BackupDirectory $BackupDirectory
    try {
        $oldBackups = @(Get-ChildItem -LiteralPath $BackupDirectory -Filter 'hosts-backup-*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -Skip 10)
        foreach ($old in $oldBackups) { Remove-Item -LiteralPath $old.FullName -Force -ErrorAction SilentlyContinue }
    } catch { }
    $content = [System.IO.File]::ReadAllText($Path)
    $pattern = [regex]::Escape($script:HostsStartMarker) + '.*?' + [regex]::Escape($script:HostsEndMarker)
    $content = [regex]::Replace($content, $pattern, '', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    $content = $content.TrimEnd() + "`r`n`r`n" + (Get-HostsBlockText -Entries $Entries -Source $Source) + "`r`n"

    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $content, $utf8)
    Clear-DnsCache

    return [pscustomobject]@{ Backup = $backup; Count = $Entries.Count }
}

function Remove-GitHubHostsEntries {
    param(
        [string]$Path = (Get-HostsFilePath),
        [switch]$SkipAdminCheck
    )

    if (-not $SkipAdminCheck -and -not (Test-IsAdministrator)) {
        throw '修改 hosts 需要管理员权限，请以管理员身份运行本工具'
    }
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到 hosts 文件：$Path" }

    $content = [System.IO.File]::ReadAllText($Path)
    $pattern = '(?ms)^' + [regex]::Escape($script:HostsStartMarker) + '.*?' + [regex]::Escape($script:HostsEndMarker) + '\s*'
    $updated = [regex]::Replace($content, $pattern, '')
    if ($updated -ne $content) {
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($Path, $updated.TrimEnd() + "`r`n", $utf8)
        Clear-DnsCache
    }
    return ($updated -ne $content)
}

function Get-HostsStatus {
    $path = Get-HostsFilePath
    $hasBlock = Test-HostsFileHasBlock -Path $path
    return [pscustomobject]@{
        Path     = $path
        HasBlock = $hasBlock
        IsAdmin  = (Test-IsAdministrator)
        Backup   = (@(Get-ChildItem (Join-Path $PSScriptRoot '..\output') -Filter 'hosts-backup-*.txt' -ErrorAction SilentlyContinue) | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
    }
}
