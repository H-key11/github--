﻿<#
    GitHub 加速器
    - 下载加速：镜像测速 + 多线程分块下载
    - 网页加速：公共 hosts 数据逐 IP 验证后写入
#>

param(
    [string]$CapturePath = ''
)

$ErrorActionPreference = 'Stop'

$script:AppRoot = $PSScriptRoot
$script:OutputDir = Join-Path $script:AppRoot 'output'
$script:LogPath = Join-Path $script:OutputDir 'error.log'
if (-not (Test-Path -LiteralPath $script:OutputDir)) {
    New-Item -ItemType Directory -Path $script:OutputDir -Force | Out-Null
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

try {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class AccNative {
    [DllImport("user32.dll")]
    public static extern bool SetProcessDPIAware();
}
'@ -ErrorAction Stop
    [void][AccNative]::SetProcessDPIAware()
} catch { }

$script:CaptureMode = -not [string]::IsNullOrWhiteSpace($CapturePath)
if ($script:CaptureMode) {
    try {
        Add-Type -ReferencedAssemblies @('System.Windows.Forms', 'System.Drawing') -TypeDefinition @'
using System.Windows.Forms;
public class AccCaptureForm : Form {
    protected override bool ShowWithoutActivation { get { return true; } }
}
'@ -ErrorAction Stop
    } catch { $script:CaptureMode = $false }
}

. (Join-Path $script:AppRoot 'lib\Downloader.ps1')
. (Join-Path $script:AppRoot 'lib\HostsAccelerator.ps1')

function Write-AppLog {
    param([string]$Message)
    try {
        Add-Content -LiteralPath $script:LogPath -Value ('[' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '] ' + $Message) -Encoding UTF8
    } catch { }
}

$script:ColorBg = [System.Drawing.ColorTranslator]::FromHtml('#F3F5F9')
$script:ColorPanel = [System.Drawing.Color]::White
$script:ColorBorder = [System.Drawing.ColorTranslator]::FromHtml('#E5E7EB')
$script:ColorText = [System.Drawing.ColorTranslator]::FromHtml('#1F2937')
$script:ColorMuted = [System.Drawing.ColorTranslator]::FromHtml('#6B7280')
$script:ColorAccent = [System.Drawing.ColorTranslator]::FromHtml('#2563EB')
$script:ColorAccentDark = [System.Drawing.ColorTranslator]::FromHtml('#1D4ED8')
$script:ColorDanger = [System.Drawing.ColorTranslator]::FromHtml('#DC2626')
$script:ColorWarn = [System.Drawing.ColorTranslator]::FromHtml('#B45309')
$script:ColorGreen = [System.Drawing.ColorTranslator]::FromHtml('#059669')

$script:UiFontName = 'Microsoft YaHei UI'
$families = @([System.Drawing.FontFamily]::Families | ForEach-Object { $_.Name })
if ($families -notcontains $script:UiFontName) { $script:UiFontName = 'Segoe UI' }

$script:UiFont = New-Object System.Drawing.Font($script:UiFontName, 9)
$script:UiFontSmall = New-Object System.Drawing.Font($script:UiFontName, 8.5)
$script:UiFontBold = New-Object System.Drawing.Font($script:UiFontName, 9, [System.Drawing.FontStyle]::Bold)
$script:TitleFont = New-Object System.Drawing.Font($script:UiFontName, 16, [System.Drawing.FontStyle]::Bold)
$script:MonoFont = New-Object System.Drawing.Font('Consolas', 9)

$script:IsAdmin = Test-IsAdministrator
$script:MirrorResults = @()
$script:BestMirror = $null
$script:DownloadJob = $null
$script:DownloadTotal = [long]0
$script:DownloadStarted = $null
$script:LastBytes = [long]0
$script:LastTick = $null
$script:BestHosts = $null
$script:Async = $null
$script:UiTimer = $null
$script:DownloadInfo = $null
$script:AutoTimer = $null
$script:LastAutoTime = $null
$script:NextAutoTime = $null

function Get-UiColor {
    param([string]$Hex)
    return [System.Drawing.ColorTranslator]::FromHtml($Hex)
}

function Format-Size {
    param([double]$Bytes)
    if ($Bytes -le 0) { return '0 B' }
    $units = @('B', 'KB', 'MB', 'GB')
    $index = 0
    $value = $Bytes
    while ($value -ge 1024 -and $index -lt 3) { $value /= 1024; $index++ }
    return ('{0:N1} {1}' -f $value, $units[$index])
}

function New-UiButton {
    param(
        [string]$Text,
        [int]$Width = 110,
        [int]$Height = 36,
        [ValidateSet('primary', 'secondary', 'dangeroutline')][string]$Kind = 'secondary'
    )

    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size($Width, $Height)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 1
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $button.Font = $script:UiFont
    $button.UseVisualStyleBackColor = $false
    $button.Margin = New-Object System.Windows.Forms.Padding(4, 0, 4, 0)

    if ($Kind -eq 'primary') {
        $button.BackColor = $script:ColorAccent
        $button.ForeColor = [System.Drawing.Color]::White
        $button.FlatAppearance.BorderColor = $script:ColorAccent
        $button.FlatAppearance.MouseOverBackColor = $script:ColorAccentDark
        $button.FlatAppearance.MouseDownBackColor = $script:ColorAccentDark
    } elseif ($Kind -eq 'dangeroutline') {
        $button.BackColor = [System.Drawing.Color]::White
        $button.ForeColor = $script:ColorDanger
        $button.FlatAppearance.BorderColor = $script:ColorDanger
        $button.FlatAppearance.MouseOverBackColor = Get-UiColor '#FEF2F2'
        $button.FlatAppearance.MouseDownBackColor = Get-UiColor '#FEE2E2'
    } else {
        $button.BackColor = [System.Drawing.Color]::White
        $button.ForeColor = $script:ColorText
        $button.FlatAppearance.BorderColor = Get-UiColor '#D1D5DB'
        $button.FlatAppearance.MouseOverBackColor = Get-UiColor '#F3F4F6'
        $button.FlatAppearance.MouseDownBackColor = Get-UiColor '#E5E7EB'
    }
    return $button
}

function Add-UiLine {
    param([object]$Parent, [string]$Dock = 'Bottom')

    $line = New-Object System.Windows.Forms.Panel
    if ($Dock -eq 'Left' -or $Dock -eq 'Right') { $line.Width = 1 } else { $line.Height = 1 }
    $line.Dock = $Dock
    $line.BackColor = $script:ColorBorder
    [void]$Parent.Controls.Add($line)
    return $line
}

# ---------------------------------------------------------------- 主窗口
if ($script:CaptureMode) { $form = New-Object AccCaptureForm } else { $form = New-Object System.Windows.Forms.Form }
$form.Text = 'GitHub 加速器'
$form.Size = New-Object System.Drawing.Size(1100, 780)
$form.MinimumSize = New-Object System.Drawing.Size(980, 700)
if ($script:CaptureMode) {
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
    $form.Location = New-Object System.Drawing.Point(-4200, 0)
    $form.ShowInTaskbar = $false
} else {
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
}
$form.BackColor = $script:ColorBg
$form.Font = $script:UiFont
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
try { $form.Icon = [System.Drawing.SystemIcons]::Application } catch { }

$header = New-Object System.Windows.Forms.Panel
$header.Dock = [System.Windows.Forms.DockStyle]::Top
$header.Height = 96
$header.BackColor = $script:ColorPanel

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = 'GitHub 加速器'
$lblTitle.Font = $script:TitleFont
$lblTitle.ForeColor = Get-UiColor '#0F172A'
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(24, 16)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = '下载加速（镜像多线程） · 网页加速（hosts 智能选优）'
$lblSubtitle.Font = $script:UiFontSmall
$lblSubtitle.ForeColor = $script:ColorMuted
$lblSubtitle.AutoSize = $true
$lblSubtitle.Location = New-Object System.Drawing.Point(26, 50)

$btnAdmin = New-UiButton -Text '以管理员身份重启' -Width 150 -Height 32 -Kind 'secondary'
$btnAdmin.Margin = New-Object System.Windows.Forms.Padding(0)

$flowHeader = New-Object System.Windows.Forms.FlowLayoutPanel
$flowHeader.Dock = [System.Windows.Forms.DockStyle]::Right
$flowHeader.Width = 180
$flowHeader.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
$flowHeader.WrapContents = $false
$flowHeader.Padding = New-Object System.Windows.Forms.Padding(0, 24, 18, 0)
$flowHeader.BackColor = $script:ColorPanel
[void]$flowHeader.Controls.Add($btnAdmin)

if ($script:IsAdmin) {
    $btnAdmin.Text = '● 管理员模式'
    $btnAdmin.ForeColor = $script:ColorGreen
    $btnAdmin.Enabled = $true
    $btnAdmin.FlatAppearance.BorderColor = Get-UiColor '#BBF7D0'
    $btnAdmin.BackColor = Get-UiColor '#F0FDF4'
}

[void]$header.Controls.AddRange(@($lblTitle, $lblSubtitle, $flowHeader, (Add-UiLine -Parent $header -Dock 'Bottom')))

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = [System.Windows.Forms.DockStyle]::Fill
$tabs.Font = $script:UiFont
$tabs.Padding = New-Object System.Drawing.Point(18, 6)
$tabs.ItemSize = New-Object System.Drawing.Size(140, 32)
$tabs.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed

$tabDownload = New-Object System.Windows.Forms.TabPage
$tabDownload.Text = '  下载加速  '
$tabDownload.BackColor = $script:ColorPanel
$tabDownload.Padding = New-Object System.Windows.Forms.Padding(0)

$tabWeb = New-Object System.Windows.Forms.TabPage
$tabWeb.Text = '  网页加速  '
$tabWeb.BackColor = $script:ColorPanel

[void]$tabs.TabPages.Add($tabDownload)
[void]$tabs.TabPages.Add($tabWeb)

# ---------------------------------------------------------------- 下载页
$lblUrl = New-Object System.Windows.Forms.Label
$lblUrl.Text = 'GitHub 链接（Release / raw / 源码包）'
$lblUrl.AutoSize = $true
$lblUrl.Location = New-Object System.Drawing.Point(24, 20)

$txtUrl = New-Object System.Windows.Forms.TextBox
$txtUrl.Location = New-Object System.Drawing.Point(24, 44)
$txtUrl.Size = New-Object System.Drawing.Size(700, 30)
$txtUrl.Font = New-Object System.Drawing.Font($script:UiFontName, 10)
$txtUrl.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle

$btnPaste = New-UiButton -Text '粘贴' -Width 76 -Height 30 -Kind 'secondary'
$btnPaste.Location = New-Object System.Drawing.Point(732, 44)

$btnTest = New-UiButton -Text '测速解析' -Width 140 -Height 30 -Kind 'primary'
$btnTest.Location = New-Object System.Drawing.Point(816, 44)

$lblMirror = New-Object System.Windows.Forms.Label
$lblMirror.Text = '尚未测速。粘贴链接后点击「测速解析」，会自动选择最快镜像。'
$lblMirror.AutoSize = $true
$lblMirror.ForeColor = $script:ColorMuted
$lblMirror.Location = New-Object System.Drawing.Point(24, 86)

$lblSave = New-Object System.Windows.Forms.Label
$lblSave.Text = '保存到'
$lblSave.AutoSize = $true
$lblSave.Location = New-Object System.Drawing.Point(24, 122)

$txtSave = New-Object System.Windows.Forms.TextBox
$txtSave.Location = New-Object System.Drawing.Point(24, 144)
$txtSave.Size = New-Object System.Drawing.Size(860, 30)
$txtSave.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$defaultDownload = Join-Path $env:USERPROFILE 'Downloads'
if (-not (Test-Path -LiteralPath $defaultDownload)) { $defaultDownload = $env:USERPROFILE }
$txtSave.Text = $defaultDownload

$btnBrowse = New-UiButton -Text '浏览…' -Width 100 -Height 30 -Kind 'secondary'
$btnBrowse.Location = New-Object System.Drawing.Point(892, 144)

$btnStart = New-UiButton -Text '开始下载' -Width 130 -Height 40 -Kind 'primary'
$btnStart.Enabled = $false
$btnStart.Location = New-Object System.Drawing.Point(24, 190)
$btnCancel = New-UiButton -Text '取消' -Width 96 -Height 40 -Kind 'dangeroutline'
$btnCancel.Location = New-Object System.Drawing.Point(162, 190)
$btnCancel.Enabled = $false
$btnOpenFolder = New-UiButton -Text '打开所在文件夹' -Width 140 -Height 40 -Kind 'secondary'
$btnOpenFolder.Location = New-Object System.Drawing.Point(266, 190)

$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.Text = '等待开始'
$lblProgress.AutoSize = $true
$lblProgress.Font = $script:UiFontBold
$lblProgress.Location = New-Object System.Drawing.Point(424, 200)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(24, 246)
$progress.Size = New-Object System.Drawing.Size(1012, 18)
$progress.Minimum = 0
$progress.Maximum = 1000
$progress.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$progress.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right

$lblSpeed = New-Object System.Windows.Forms.Label
$lblSpeed.Text = ''
$lblSpeed.AutoSize = $true
$lblSpeed.ForeColor = $script:ColorMuted
$lblSpeed.Location = New-Object System.Drawing.Point(24, 272)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Location = New-Object System.Drawing.Point(24, 300)
$logBox.Size = New-Object System.Drawing.Size(1012, 300)
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$logBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$logBox.BackColor = Get-UiColor '#F9FAFB'
$logBox.Font = $script:MonoFont
$logBox.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Bottom

[void]$tabDownload.Controls.AddRange(@(
        $lblUrl, $txtUrl, $btnPaste, $btnTest, $lblMirror,
        $lblSave, $txtSave, $btnBrowse,
        $btnStart, $btnCancel, $btnOpenFolder, $lblProgress,
        $progress, $lblSpeed, $logBox
    ))

# ---------------------------------------------------------------- 网页页
$lblWebInfo = New-Object System.Windows.Forms.Label
$lblWebInfo.Text = '从 GitHub520 获取公共 hosts 数据，逐个 IP 验证 TLS 与延迟后，只写入可用的解析记录。'
$lblWebInfo.AutoSize = $true
$lblWebInfo.ForeColor = $script:ColorMuted
$lblWebInfo.Location = New-Object System.Drawing.Point(24, 20)

$btnFetchHosts = New-UiButton -Text '立即优化并切换' -Width 176 -Height 36 -Kind 'primary'
$btnFetchHosts.Location = New-Object System.Drawing.Point(24, 48)
$btnApplyHosts = New-UiButton -Text '应用 hosts 加速' -Width 140 -Height 36 -Kind 'secondary'
$btnApplyHosts.Enabled = $false
$btnApplyHosts.Location = New-Object System.Drawing.Point(214, 48)
$btnRestoreHosts = New-UiButton -Text '还原 hosts' -Width 110 -Height 36 -Kind 'dangeroutline'
$btnRestoreHosts.Location = New-Object System.Drawing.Point(368, 48)
$btnRefreshHosts = New-UiButton -Text '刷新状态' -Width 100 -Height 36 -Kind 'secondary'
$btnRefreshHosts.Location = New-Object System.Drawing.Point(492, 48)

$chkAuto = New-Object System.Windows.Forms.CheckBox
$chkAuto.Text = '自动切换最优 IP（每 10 分钟）'
$chkAuto.AutoSize = $true
$chkAuto.Checked = $true
$chkAuto.Font = $script:UiFont
$chkAuto.Location = New-Object System.Drawing.Point(620, 58)

$lblHostsStatus = New-Object System.Windows.Forms.Label
$lblHostsStatus.Text = '正在检查…'
$lblHostsStatus.AutoSize = $true
$lblHostsStatus.Font = $script:UiFontBold
$lblHostsStatus.Location = New-Object System.Drawing.Point(24, 98)

$lvHosts = New-Object System.Windows.Forms.ListView
$lvHosts.Location = New-Object System.Drawing.Point(24, 128)
$lvHosts.Size = New-Object System.Drawing.Size(1012, 330)
$lvHosts.View = [System.Windows.Forms.View]::Details
$lvHosts.FullRowSelect = $true
$lvHosts.GridLines = $false
$lvHosts.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$lvHosts.Font = $script:UiFont
$lvHosts.BackColor = [System.Drawing.Color]::White
$lvHosts.Columns.Add('域名', 360) | Out-Null
$lvHosts.Columns.Add('IP 地址', 170) | Out-Null
$lvHosts.Columns.Add('延迟', 90) | Out-Null
$lvHosts.Columns.Add('HTTP', 80) | Out-Null
$lvHosts.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right

$lblHostsWarn = New-Object System.Windows.Forms.Label
$lblHostsWarn.Text = '提示：hosts 方案依赖公共 IP，可能随 GitHub CDN 调整而失效；写入前会自动备份，可随时点「还原 hosts」。'
$lblHostsWarn.AutoSize = $true
$lblHostsWarn.ForeColor = $script:ColorWarn
$lblHostsWarn.Location = New-Object System.Drawing.Point(24, 474)

$lblHostsDetail = New-Object System.Windows.Forms.Label
$lblHostsDetail.Text = ''
$lblHostsDetail.AutoSize = $true
$lblHostsDetail.ForeColor = $script:ColorMuted
$lblHostsDetail.Location = New-Object System.Drawing.Point(24, 502)

[void]$tabWeb.Controls.AddRange(@(
        $lblWebInfo, $btnFetchHosts, $btnApplyHosts, $btnRestoreHosts, $btnRefreshHosts, $chkAuto,
        $lblHostsStatus, $lvHosts, $lblHostsWarn, $lblHostsDetail
    ))

[void]$form.Controls.Add($tabs)
[void]$form.Controls.Add($header)

# ---------------------------------------------------------------- 异步任务（runspace）
function Start-AsyncRunspace {
    param(
        [ValidateSet('mirror', 'hosts', 'auto')][string]$Mode,
        [string]$Url = '',
        [string]$CurrentEntriesJson = ''
    )

    $runspace = [runspacefactory]::CreateRunspace()
    $runspace.ApartmentState = 'MTA'
    $runspace.ThreadOptions = 'ReuseThread'
    $runspace.Open()

    $shell = [powershell]::Create()
    $shell.Runspace = $runspace

    if ($Mode -eq 'mirror') {
        [void]$shell.AddScript({
                param($Root, $Url)
                . (Join-Path $Root 'lib\Downloader.ps1')
                return @(Measure-AllDownloadMirrors -Url $Url -RangeBytes 1048576 -TimeoutSeconds 10)
            }).AddArgument($script:AppRoot).AddArgument($Url)
    } elseif ($Mode -eq 'auto') {
        [void]$shell.AddScript({
                param($Root, $CurrentJson)
                . (Join-Path $Root 'lib\HostsAccelerator.ps1')
                $current = @()
                if ($CurrentJson) {
                    $parsed = $CurrentJson | ConvertFrom-Json
                    if ($null -ne $parsed) { $current = @($parsed) }
                }
                return Get-BestGitHubHosts -ExtraEntries $current
            }).AddArgument($script:AppRoot).AddArgument($CurrentEntriesJson)
    } else {
        [void]$shell.AddScript({
                param($Root)
                . (Join-Path $Root 'lib\HostsAccelerator.ps1')
                return Get-BestGitHubHosts
            }).AddArgument($script:AppRoot)
    }

    $handle = $shell.BeginInvoke()
    $script:Async = [pscustomobject]@{
        Mode     = $Mode
        Shell    = $shell
        Handle   = $handle
        Runspace = $runspace
    }
}

function Complete-AsyncRunspace {
    if ($null -eq $script:Async) { return }

    $async = $script:Async
    $script:Async = $null
    try {
        $results = @($async.Shell.EndInvoke($async.Handle))
    } catch {
        Write-AppLog ('异步任务失败：' + $_.Exception.ToString())
        $results = @()
        $error = $_.Exception.Message
    } finally {
        try { $async.Shell.Dispose() } catch { }
        try { $async.Runspace.Dispose() } catch { }
    }

    if ($async.Mode -eq 'mirror') {
        Finish-MirrorTest -Results $results
    } elseif ($async.Mode -eq 'auto') {
        Finish-AutoOptimize -Results $results
    } else {
        Finish-HostsTest -Results $results
    }
}

# ---------------------------------------------------------------- 下载逻辑
function Write-Log {
    param([string]$Text)
    $logBox.AppendText($Text + "`r`n")
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
}

function Apply-StartButtonStyle {
    if ($btnStart.Enabled) {
        $btnStart.BackColor = $script:ColorAccent
        $btnStart.ForeColor = [System.Drawing.Color]::White
        $btnStart.FlatAppearance.BorderColor = $script:ColorAccent
    } else {
        $btnStart.BackColor = Get-UiColor '#E5E7EB'
        $btnStart.ForeColor = Get-UiColor '#9CA3AF'
        $btnStart.FlatAppearance.BorderColor = Get-UiColor '#E5E7EB'
    }
}

function Set-DownloadBusy {
    param([bool]$Busy)

    $txtUrl.Enabled = -not $Busy
    $txtSave.Enabled = -not $Busy
    $btnBrowse.Enabled = -not $Busy
    $btnTest.Enabled = -not $Busy
    $btnPaste.Enabled = -not $Busy
    $btnStart.Enabled = (-not $Busy) -and ($null -ne $script:BestMirror)
    Apply-StartButtonStyle
    $btnCancel.Enabled = $Busy
}

function Finish-MirrorTest {
    param([object[]]$Results)

    $script:MirrorResults = @($Results)
    $logBox.Text = ''
    Write-Log '镜像测速结果：'
    Write-Log ('{0,-14} {1,-6} {2,12} {3,10} {4,12} {5}' -f '镜像', 'HTTP', '速度', '分块', '文件大小', '')

    foreach ($result in $script:MirrorResults) {
        $speedText = Format-Size -Bytes $result.SpeedBytes
        $rangeText = if ($result.RangeSupported) { '支持' } else { '不支持' }
        $sizeText = if ($result.TotalSize -gt 0) { Format-Size -Bytes $result.TotalSize } else { '未知' }
        $status = if ($result.Ok) { '' } else { '连接失败' }
        Write-Log ('{0,-14} {1,-6} {2,12}/s {3,10} {4,12} {5}' -f $result.MirrorName, $result.HttpCode, $speedText, $rangeText, $sizeText, $status)
    }

    $usable = @($script:MirrorResults | Where-Object { $_.Ok -and $_.RangeSupported -and $_.TotalSize -gt 0 })
    $preferred = @($usable | Where-Object { $_.MirrorName -ne 'GitHub 直连' })
    $best = $preferred | Sort-Object SpeedBytes -Descending | Select-Object -First 1
    if (-not $best) {
        $best = $usable | Sort-Object SpeedBytes -Descending | Select-Object -First 1
    }
    if (-not $best) {
        $best = $script:MirrorResults | Where-Object { $_.Ok -and $_.TotalSize -gt 0 } | Sort-Object SpeedBytes -Descending | Select-Object -First 1
    }
    if ($best) {
        $sizeGroups = @($usable | Group-Object TotalSize | Sort-Object Count -Descending)
        if ($sizeGroups.Count -gt 0) {
            $consensus = [long]$sizeGroups[0].Name
            if ($consensus -gt 0) { $best.TotalSize = $consensus }
        }
    }

    if ($best) {
        $script:BestMirror = $best
        $lblMirror.Text = "已选择：$($best.MirrorName) ｜ " + (Format-Size -Bytes $best.SpeedBytes) + '/s ｜ 文件 ' + (Format-Size -Bytes $best.TotalSize)
        $lblMirror.ForeColor = $script:ColorGreen

        if ($script:DownloadInfo) {
            $current = $txtSave.Text.Trim()
            if ($current -and (Test-Path -LiteralPath $current -PathType Container)) {
                $dir = $current
            } else {
                $dir = Split-Path -Parent $current
                if (-not $dir) { $dir = $defaultDownload }
            }
            $txtSave.Text = Join-Path $dir $script:DownloadInfo.FileName
        }

        $btnStart.Enabled = $true
        Apply-StartButtonStyle
        $lblProgress.Text = '准备就绪'
        $lblSpeed.Text = '点击「开始下载」，将使用 ' + $best.MirrorName + ' 分块下载。'
    } else {
        $script:BestMirror = $null
        $lblMirror.Text = '所有镜像都连接失败，请检查网络或链接。'
        $lblMirror.ForeColor = $script:ColorDanger
        $btnStart.Enabled = $false
    }
}

function Start-MirrorTest {
    if ($null -ne $script:Async) { return }
    try {
        $info = Get-GitHubDownloadInfo -Url $txtUrl.Text
        $script:DownloadInfo = $info
        $script:BestMirror = $null
        $btnStart.Enabled = $false
        $lblMirror.Text = '正在测速，请稍候…'
        $lblMirror.ForeColor = $script:ColorMuted
        $logBox.Text = ''
        Write-Log "文件：$($info.FileName)"
        Start-AsyncRunspace -Mode 'mirror' -Url $info.Url
        $script:UiTimer.Start()
    } catch {
        Show-Error $_.Exception.Message '链接无效'
    }
}

function Start-Download {
    if ($null -ne $script:Async) { return }
    if ($null -eq $script:BestMirror) {
        Show-Error '请先点击「测速解析」选择镜像。'
        return
    }

    $target = $txtSave.Text.Trim()
    if (-not $target) { Show-Error '请选择保存路径。'; return }
    $targetDir = Split-Path -Parent $target
    if ($targetDir -and -not (Test-Path -LiteralPath $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }

    $total = [long]$script:BestMirror.TotalSize
    if ($total -le 0) { Show-Error '无法获取文件大小，不能开始下载。'; return }

    try {
        if ($script:BestMirror.RangeSupported -and $total -gt 1048576) {
            $partCount = 4
            if ($total -gt 100MB) { $partCount = 8 }
            $script:DownloadJob = Start-DownloadJob -Url $script:DownloadInfo.Url -Prefix $script:BestMirror.Prefix -TotalSize $total -Target $target -PartCount $partCount
        } else {
            $script:DownloadJob = Start-SingleDownloadJob -Url $script:DownloadInfo.Url -Prefix $script:BestMirror.Prefix -TotalSize $total -Target $target
        }
    } catch {
        Show-Error ('启动下载失败：' + $_.Exception.Message)
        return
    }

    $script:DownloadTotal = $total
    $script:DownloadStarted = Get-Date
    $script:LastBytes = 0
    $script:LastTick = Get-Date
    $progress.Value = 0
    $lblProgress.Text = '正在连接…'
    $lblSpeed.Text = ''
    Set-DownloadBusy -Busy $true
    $script:UiTimer.Start()
}

function Update-DownloadProgress {
    if ($null -eq $script:DownloadJob) { return }

    $bytes = Get-DownloadJobBytes -Job $script:DownloadJob
    $now = Get-Date
    $elapsed = ($now - $script:LastTick).TotalSeconds
    $speed = 0
    if ($elapsed -gt 0) { $speed = ($bytes - $script:LastBytes) / $elapsed }
    $script:LastBytes = $bytes
    $script:LastTick = $now

    $percent = 0
    if ($script:DownloadTotal -gt 0) { $percent = [Math]::Min(100, [Math]::Round($bytes * 100 / $script:DownloadTotal, 1)) }
    $progress.Value = [int]($percent * 10)
    $lblProgress.Text = "$percent%  " + (Format-Size -Bytes $bytes) + ' / ' + (Format-Size -Bytes $script:DownloadTotal)
    $lblSpeed.Text = (Format-Size -Bytes $speed) + '/s'

    if (Test-DownloadJobComplete -Job $script:DownloadJob) {
        try {
            $result = Complete-DownloadJob -Job $script:DownloadJob
            $lblProgress.Text = '下载完成：' + (Format-Size -Bytes $result.Size)
            $lblSpeed.Text = $result.Path
            $progress.Value = 1000
            $script:DownloadJob = $null
            Set-DownloadBusy -Busy $false
            $script:UiTimer.Stop()
            [void][System.Windows.Forms.MessageBox]::Show(
                "下载完成：`r`n`r`n$($result.Path)`r`n`r`n大小：$(Format-Size -Bytes $result.Size)",
                '下载完成', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        } catch {
            Write-AppLog ('下载失败：' + $_.Exception.ToString())
            $lblProgress.Text = '下载失败'
            $lblSpeed.Text = $_.Exception.Message
            $script:DownloadJob = $null
            Set-DownloadBusy -Busy $false
            $script:UiTimer.Stop()
            Show-Error ('下载失败：' + $_.Exception.Message)
        }
    }
}

function Cancel-Download {
    if ($null -eq $script:DownloadJob) { return }
    Stop-DownloadJob -Job $script:DownloadJob
    $script:DownloadJob = $null
    $script:UiTimer.Stop()
    Set-DownloadBusy -Busy $false
    $lblProgress.Text = '已取消'
    $lblSpeed.Text = ''
    $progress.Value = 0
}

function Open-TargetFolder {
    $path = $txtSave.Text.Trim()
    if (-not $path) { return }
    $dir = Split-Path -Parent $path
    if ($dir -and (Test-Path -LiteralPath $dir)) {
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + $path + '"')
    } elseif ($dir) {
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $dir + '"')
    }
}

# ---------------------------------------------------------------- 网页加速逻辑
function Refresh-HostsStatus {
    $status = Get-HostsStatus
    $script:HostsStatus = $status
    if ($status.HasBlock) {
        $lblHostsStatus.Text = 'hosts 加速：已启用'
        $lblHostsStatus.ForeColor = $script:ColorGreen
    } else {
        $lblHostsStatus.Text = 'hosts 加速：未启用'
        $lblHostsStatus.ForeColor = $script:ColorMuted
    }
    if (-not $status.IsAdmin) {
        $lblHostsStatus.Text += '（需要管理员权限才能修改）'
        $lblHostsStatus.ForeColor = $script:ColorWarn
    }
    Update-AutoStatus
}

function Start-HostsTest {
    if ($null -ne $script:Async) { return }
    $script:BestHosts = $null
    $lblHostsStatus.Text = '正在获取 hosts 数据并测速，请稍候…'
    $lblHostsStatus.ForeColor = $script:ColorMuted
    $lvHosts.Items.Clear()
    $btnApplyHosts.Enabled = $false
    Start-AsyncRunspace -Mode 'hosts'
    $script:UiTimer.Start()
}

function Finish-HostsTest {
    param([object[]]$Results)

    $best = $null
    if ($Results.Count -gt 0) { $best = $Results[0] }
    if ($null -eq $best -or -not $best.Entries -or $best.Entries.Count -eq 0) {
        $lblHostsStatus.Text = '没有找到可用的 GitHub IP，请稍后重试。'
        $lblHostsStatus.ForeColor = $script:ColorDanger
        return
    }

    $script:BestHosts = $best
    $lvHosts.BeginUpdate()
    try {
        $lvHosts.Items.Clear()
        foreach ($entry in $best.Entries) {
            $item = New-Object System.Windows.Forms.ListViewItem([string]$entry.Domain)
            [void]$item.SubItems.Add([string]$entry.IP)
            [void]$item.SubItems.Add(([int]$entry.LatencyMs).ToString() + ' ms')
            [void]$item.SubItems.Add([string]$entry.HttpCode)
            if ($entry.LatencyMs -lt 300) { $item.ForeColor = $script:ColorGreen }
            elseif ($entry.LatencyMs -gt 1000) { $item.ForeColor = $script:ColorWarn }
            [void]$lvHosts.Items.Add($item)
        }
    } finally {
        $lvHosts.EndUpdate()
    }

    $lblHostsStatus.Text = "测速完成：$($best.Entries.Count) 个域名可用"
    $lblHostsStatus.ForeColor = $script:ColorGreen
    $lblHostsDetail.Text = '数据来源：GitHub520（raw.hellogithub.com/hosts）'
    $btnApplyHosts.Enabled = $true
    $btnApplyHosts.ForeColor = $script:ColorText
    $btnApplyHosts.FlatAppearance.BorderColor = Get-UiColor '#D1D5DB'
}

function Update-AutoStatus {
    $text = '自动切换：'
    if ($chkAuto.Checked) { $text += '开启' } else { $text += '关闭' }
    if ($script:LastAutoTime) { $text += ' · 上次 ' + $script:LastAutoTime.ToString('HH:mm') }
    if ($chkAuto.Checked -and $script:NextAutoTime) { $text += ' · 下次 ' + $script:NextAutoTime.ToString('HH:mm') }
    $lblHostsDetail.Text = $text
}

function Get-HostsSwitchDecision {
    param(
        [Parameter(Mandatory)]$Best,
        [object[]]$Current = @()
    )

    $currentMap = @{}
    foreach ($entry in @($Current)) {
        if ($entry) { $currentMap[[string]$entry.Domain] = [string]$entry.IP }
    }

    $latency = @{}
    foreach ($detail in @($Best.Details)) {
        foreach ($tested in @($detail.Tested)) {
            $latency[[string]$detail.Domain + '|' + [string]$tested.IP] = $tested
        }
    }

    $needsSwitch = $false
    $reasons = New-Object System.Collections.Generic.List[string]

    foreach ($entry in @($Best.Entries)) {
        $domain = [string]$entry.Domain
        $currentIp = $currentMap[$domain]
        if (-not $currentIp) {
            $needsSwitch = $true
            $reasons.Add($domain + ' 新增')
            continue
        }
        if ($currentIp -eq $entry.IP) { continue }

        $currentResult = $latency[$domain + '|' + $currentIp]
        if ($null -eq $currentResult -or -not $currentResult.Ok) {
            $needsSwitch = $true
            $reasons.Add($domain + ' 当前 IP 失效')
            continue
        }
        $gain = $currentResult.LatencyMs - $entry.LatencyMs
        if ($entry.LatencyMs -gt 0 -and $currentResult.LatencyMs -gt 0 -and $entry.LatencyMs -lt ($currentResult.LatencyMs * 0.7) -and $gain -gt 80) {
            $needsSwitch = $true
            $reasons.Add($domain + ' 提速')
        }
    }

    $applied = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @($Best.Entries)) { $applied.Add($entry) }
    $bestDomains = @{}
    foreach ($entry in @($Best.Entries)) { $bestDomains[[string]$entry.Domain] = $true }
    foreach ($entry in @($Current)) {
        if ($entry -and -not $bestDomains.ContainsKey([string]$entry.Domain) -and $script:HostsDomains -contains [string]$entry.Domain) {
            $applied.Add($entry)
            $bestDomains[[string]$entry.Domain] = $true
        }
    }

    return [pscustomobject]@{
        NeedsSwitch = $needsSwitch
        Reasons     = $reasons.ToArray()
        Entries     = $applied.ToArray()
    }
}

function Start-AutoOptimize {
    if ($null -ne $script:Async) { return }
    try {
        $current = @(Get-AppliedGitHubHosts)
        $json = ''
        if ($current.Count -gt 0) {
            $json = ConvertTo-Json -InputObject @($current) -Compress -Depth 5
        }
        $lblHostsStatus.Text = '正在获取最新 hosts 数据并测速…'
        $lblHostsStatus.ForeColor = $script:ColorMuted
        $btnFetchHosts.Enabled = $false
        Start-AsyncRunspace -Mode 'auto' -CurrentEntriesJson $json
        $script:UiTimer.Start()
    } catch {
        $btnFetchHosts.Enabled = $true
        Show-Error ('自动优化启动失败：' + $_.Exception.Message)
    }
}

function Finish-AutoOptimize {
    param([object[]]$Results)

    $btnFetchHosts.Enabled = $true
    $best = $null
    if ($Results.Count -gt 0) { $best = $Results[0] }

    if ($null -eq $best -or -not $best.Entries -or $best.Entries.Count -eq 0) {
        $lblHostsStatus.Text = '没有获取到可用 IP，稍后会重试。'
        $lblHostsStatus.ForeColor = $script:ColorDanger
        $script:NextAutoTime = (Get-Date).AddMinutes(10)
        Update-AutoStatus
        return
    }

    $script:BestHosts = $best
    $lvHosts.BeginUpdate()
    try {
        $lvHosts.Items.Clear()
        foreach ($entry in $best.Entries) {
            $item = New-Object System.Windows.Forms.ListViewItem([string]$entry.Domain)
            [void]$item.SubItems.Add([string]$entry.IP)
            [void]$item.SubItems.Add(([int]$entry.LatencyMs).ToString() + ' ms')
            [void]$item.SubItems.Add([string]$entry.HttpCode)
            if ($entry.LatencyMs -lt 300) { $item.ForeColor = $script:ColorGreen }
            elseif ($entry.LatencyMs -gt 1000) { $item.ForeColor = $script:ColorWarn }
            [void]$lvHosts.Items.Add($item)
        }
    } finally {
        $lvHosts.EndUpdate()
    }
    $btnApplyHosts.Enabled = $true
    $btnApplyHosts.ForeColor = $script:ColorText
    $btnApplyHosts.FlatAppearance.BorderColor = Get-UiColor '#D1D5DB'

    $current = @(Get-AppliedGitHubHosts)
    $decision = Get-HostsSwitchDecision -Best $best -Current $current
    $now = Get-Date
    $script:LastAutoTime = $now
    $script:NextAutoTime = $now.AddMinutes(10)

    if (-not $script:IsAdmin) {
        $lblHostsStatus.Text = "测速完成：$($best.Entries.Count) 个域名可用，但自动写入需要管理员权限"
        $lblHostsStatus.ForeColor = $script:ColorWarn
        Update-AutoStatus
        return
    }

    if (-not $decision.NeedsSwitch) {
        $lblHostsStatus.Text = "已是最优：$($best.Entries.Count) 个域名无需切换"
        $lblHostsStatus.ForeColor = $script:ColorGreen
        Update-AutoStatus
        return
    }

    try {
        $result = Set-GitHubHostsEntries -Entries $decision.Entries -Source 'GitHub520'
        $reasonText = ''
        if ($decision.Reasons.Count -gt 0) {
            $reasonText = '（' + (($decision.Reasons | Select-Object -First 3) -join '；') + '）'
        }
        $lblHostsStatus.Text = "已自动切换：$($result.Count) 条记录 $reasonText"
        $lblHostsStatus.ForeColor = $script:ColorGreen
        Update-AutoStatus
    } catch {
        Write-AppLog ('自动切换 hosts 失败：' + $_.Exception.ToString())
        $lblHostsStatus.Text = '自动切换失败：' + $_.Exception.Message
        $lblHostsStatus.ForeColor = $script:ColorDanger
        Update-AutoStatus
    }
}

function Apply-HostsAcceleration {
    if (-not $script:IsAdmin) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "修改 hosts 需要管理员权限。`r`n`r`n是否以管理员身份重新启动本工具？",
            '需要管理员权限',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Restart-AsAdmin }
        return
    }

    if ($null -eq $script:BestHosts -or $script:BestHosts.Entries.Count -eq 0) {
        Show-Error '请先点击「获取最新 IP 并测速」。'
        return
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "将向 hosts 写入 $($script:BestHosts.Entries.Count) 条 GitHub 解析记录，并刷新 DNS。`r`n`r`n修改前会自动备份。是否继续？",
        '应用 hosts 加速',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    try {
        $result = Set-GitHubHostsEntries -Entries $script:BestHosts.Entries -Source 'GitHub520'
        $script:LastAutoTime = Get-Date
        $script:NextAutoTime = $script:LastAutoTime.AddMinutes(10)
        Refresh-HostsStatus
        [void][System.Windows.Forms.MessageBox]::Show(
            "hosts 加速已应用，共 $($result.Count) 条记录。`r`n`r`n备份：$($result.Backup)`r`n`r`n如访问异常，点「还原 hosts」即可恢复。",
            '应用成功', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch {
        Write-AppLog ('应用 hosts 失败：' + $_.Exception.ToString())
        Show-Error ('应用 hosts 失败：' + $_.Exception.Message)
    }
}

function Restore-HostsAcceleration {
    if (-not $script:IsAdmin) {
        Show-Error '还原 hosts 需要管理员权限，请以管理员身份重新启动本工具。'
        return
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        '确定要移除本工具写入的 hosts 记录吗？',
        '还原 hosts',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    try {
        $changed = Remove-GitHubHostsEntries
        Refresh-HostsStatus
        $text = if ($changed) { '已被移除，并刷新了 DNS。' } else { '未发现本工具写入的记录。' }
        [void][System.Windows.Forms.MessageBox]::Show($text, '还原完成', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch {
        Write-AppLog ('还原 hosts 失败：' + $_.Exception.ToString())
        Show-Error ('还原 hosts 失败：' + $_.Exception.Message)
    }
}

function Restart-AsAdmin {
    try {
        $shell = (Get-Process -Id $PID).Path
        $arguments = '-NoProfile -STA -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        Start-Process -FilePath $shell -ArgumentList $arguments -Verb RunAs
        $form.Close()
    } catch {
        Show-Error ('提权失败：' + $_.Exception.Message)
    }
}

# ---------------------------------------------------------------- 通用
function Show-Error {
    param([string]$Text, [string]$Title = '提示')
    [void][System.Windows.Forms.MessageBox]::Show($Text, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
}

function Show-Info {
    param([string]$Text, [string]$Title = '提示')
    [void][System.Windows.Forms.MessageBox]::Show($Text, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
}

# ---------------------------------------------------------------- 事件
$btnPaste.Add_Click({
    if ([System.Windows.Forms.Clipboard]::ContainsText()) {
        $txtUrl.Text = [System.Windows.Forms.Clipboard]::GetText().Trim()
    }
})

$btnTest.Add_Click({ Start-MirrorTest })
$btnStart.Add_Click({ Start-Download })
$btnCancel.Add_Click({ Cancel-Download })
$btnOpenFolder.Add_Click({ Open-TargetFolder })
$btnBrowse.Add_Click({
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.InitialDirectory = Split-Path -Parent $txtSave.Text
    $dialog.FileName = Split-Path -Leaf $txtSave.Text
    $dialog.Filter = '所有文件 (*.*)|*.*'
    if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtSave.Text = $dialog.FileName
    }
})

$btnFetchHosts.Add_Click({ Start-AutoOptimize })
$btnApplyHosts.Add_Click({ Apply-HostsAcceleration })
$btnRestoreHosts.Add_Click({ $chkAuto.Checked = $false; Restore-HostsAcceleration })
$btnRefreshHosts.Add_Click({ Refresh-HostsStatus })
$btnAdmin.Add_Click({
    if (-not $script:IsAdmin) { Restart-AsAdmin }
})

$chkAuto.Add_CheckedChanged({
    Update-AutoStatus
    if ($chkAuto.Checked) {
        if (-not $script:IsAdmin) {
            $lblHostsStatus.Text = '自动切换需要管理员权限，请以管理员身份重启'
            $lblHostsStatus.ForeColor = $script:ColorWarn
            return
        }
        if ($null -eq $script:Async -and $null -eq $script:DownloadJob) { Start-AutoOptimize }
    }
})

$form.Add_Shown({
    Apply-StartButtonStyle
    $btnApplyHosts.ForeColor = Get-UiColor '#9CA3AF'
    $btnApplyHosts.FlatAppearance.BorderColor = Get-UiColor '#E5E7EB'
    Refresh-HostsStatus
    Update-AutoStatus
    if (-not $script:CaptureMode -and $chkAuto.Checked -and $script:IsAdmin) {
        $script:NextAutoTime = (Get-Date)
        Start-AutoOptimize
        $script:AutoTimer.Start()
    }
    if ($script:CaptureMode) {
        $tabs.SelectedIndex = 1
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 500
        [System.Windows.Forms.Application]::DoEvents()
        try {
            $bitmap = New-Object System.Drawing.Bitmap($form.Width, $form.Height)
            $form.DrawToBitmap($bitmap, (New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)))
            $bitmap.Save($CapturePath, [System.Drawing.Imaging.ImageFormat]::Png)
            $bitmap.Dispose()
        } catch {
            Write-AppLog ('截图失败：' + $_.Exception.ToString())
        }
        $form.Close()
    }
})

$form.Add_FormClosing({
    if ($script:UiTimer) { $script:UiTimer.Stop() }
    if ($script:AutoTimer) { $script:AutoTimer.Stop() }
    if ($null -ne $script:DownloadJob) { Stop-DownloadJob -Job $script:DownloadJob }
    if ($null -ne $script:Async) {
        try { $script:Async.Shell.Stop() } catch { }
        try { $script:Async.Shell.Dispose() } catch { }
        try { $script:Async.Runspace.Dispose() } catch { }
        $script:Async = $null
    }
})

$script:UiTimer = New-Object System.Windows.Forms.Timer
$script:UiTimer.Interval = 300
$script:UiTimer.Add_Tick({
    if ($null -ne $script:Async) {
        if ($script:Async.Handle.IsCompleted) {
            $script:UiTimer.Stop()
            Complete-AsyncRunspace
        }
        return
    }
    if ($null -ne $script:DownloadJob) {
        Update-DownloadProgress
    }
})

$script:AutoTimer = New-Object System.Windows.Forms.Timer
$script:AutoTimer.Interval = 60000
$script:AutoTimer.Add_Tick({
    if (-not $chkAuto.Checked) { $script:AutoTimer.Stop(); return }
    if ($null -ne $script:Async -or $null -ne $script:DownloadJob) { return }
    if (-not $script:IsAdmin) { return }
    if ($script:NextAutoTime -and (Get-Date) -lt $script:NextAutoTime) { return }
    Start-AutoOptimize
})

try {
    [void]$form.ShowDialog()
} catch {
    Write-AppLog ('主界面异常：' + $_.Exception.ToString())
    Show-Error ("程序发生异常：`r`n`r`n" + $_.Exception.Message + "`r`n`r`n详细信息已写入 output\error.log")
} finally {
    $form.Dispose()
}
