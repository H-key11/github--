# GitHub 加速器

Windows 上的 GitHub 下载与网页访问加速工具：

- **下载加速**：Release / raw / 源码包链接自动测速选最快镜像，多线程分块下载
- **网页加速**：自动获取最新 GitHub520 数据，逐个 IP 验证 TLS 与延迟，自动切换到最优 IP；可一键还原

![下载加速](assets/screenshot-download.png)

![网页加速](assets/screenshot-web.png)

## 快速开始

1. 双击 `启动GitHub加速器.bat`
2. 下载加速：粘贴 GitHub 链接 → 点「测速解析」→ 选保存位置 → 「开始下载」
3. 网页加速：以管理员身份启动后会自动优化并写入；也可以切到「网页加速」点「立即优化并切换」

> 网页加速需要修改系统 hosts，建议右键工具选择「以管理员身份运行」，或在工具内点「以管理员身份重启」。

## 下载加速

支持的链接：

- `https://github.com/用户/仓库/releases/download/...`
- `https://raw.githubusercontent.com/...`
- `https://codeload.github.com/...`
- `https://github.com/用户/仓库/archive/refs/heads/main.zip`
- `https://objects.githubusercontent.com/...`

工作方式：

- 依次测试 `ghfast.top`、`ghproxy.net`、`gh-proxy.com` 与 GitHub 直连
- 优先选择可用且支持 `Range` 的镜像（直连只作为兜底）
- 文件大于 1 MB 时自动 4 线程分块下载，大于 100 MB 时 8 线程
- 下载完成后合并分块、校验总大小；失败或取消会清理临时文件

界面会显示每个镜像的 HTTP 状态、测速速度、是否支持分块以及文件大小；下载中有进度、速度和百分比。

## 网页加速（自动切换最新最优）

- 数据来源：GitHub520（`https://raw.hellogithub.com/hosts`），每次优化都会重新拉取，不依赖旧缓存
- 对候选 IP 使用 `curl --resolve` 实际访问对应域名，校验 TLS 证书与响应，再按延迟选出最优
- **自动模式**（默认开启，仅在工具运行期间生效）：启动时立即检测一次，之后每 10 分钟重新获取最新数据并测速
  - 当前 hosts 中没有记录、当前 IP 失效，或新 IP 比当前 IP 快 30% 且延迟低 80 ms 以上时，自动切换
  - 当前已经是最优时不写文件，避免无意义地反复修改
- 只写入验证通过的域名，例如 `github.com`、`api.github.com`、`raw.githubusercontent.com`、`codeload.github.com`、`objects.githubusercontent.com` 等
- 写入前自动备份 hosts 到 `output\hosts-backup-<时间>.txt`，最多保留最近 10 份
- 只增加带标记的一段记录，不会改动你原有的 hosts 内容
- 点「还原 hosts」会移除记录并刷新 DNS，同时关闭自动切换，避免刚还原又被写回

> 自动写入需要管理员权限；未提权时只测速、不写 hosts，并会提示「以管理员身份重启」。

> 关闭工具后自动切换停止，hosts 会保持最后一次写入的结果；再次打开工具会继续检测。

> hosts 方案依赖公共 IP，GitHub 的 CDN 调整后可能失效。失效时点「立即优化并切换」重新选优即可。

## 原理说明

- 下载：使用系统自带的 `curl.exe` 对镜像做 Range 测速和分块请求，PowerShell 负责调度、进度与合并
- 网页：hosts 只负责把域名指向可用 IP，HTTPS 证书仍由 GitHub 正常校验；工具会验证证书，不会绕过 TLS
- 工具不上传任何数据，也不修改浏览器代理设置

## 常见问题

**测速全部失败**

- 检查网络是否能访问 `ghfast.top` 等镜像
- 公司网络/代理可能拦截；尝试切换网络
- 过几分钟再试，公共镜像偶尔会限流

**选中镜像后下载失败（SSL/连接错误）**

- 公共镜像不稳定，重新点「测速解析」换一个镜像
- 大文件建议优先使用 `ghfast.top`

**应用 hosts 提示需要管理员权限**

- 关闭工具，右键 `启动GitHub加速器.bat` →「以管理员身份运行」
- 或在工具右上角点「以管理员身份重启」

**hosts 加速后 GitHub 打不开**

- 点「还原 hosts」，工具会移除记录、刷新 DNS，并关闭自动切换
- 也可以重新点「立即优化并切换」，选择延迟更低的 IP

**自动切换会频繁改 hosts 吗**

- 每 10 分钟检查一次；只有当前 IP 失效或新 IP 快 30% 且低 80 ms 以上才写入
- 当前已经最优时不会改动文件，因此不会反复刷新
- 每次切换都会备份，`output` 下最多保留最近 10 份 hosts 备份

**杀毒软件误报**

- 工具是 PowerShell + 系统 curl，可能会被启发式规则误报；可将目录加入信任

## 文件结构

```
GitHub加速器/
├─ 启动GitHub加速器.bat
├─ app.ps1                 图形界面与流程
├─ lib/
│  ├─ Downloader.ps1       镜像测速、分块下载、合并
│  └─ HostsAccelerator.ps1 hosts 获取、验证、写入、还原
├─ assets/                 界面截图
├─ output/                 错误日志与 hosts 备份
└─ README.md
```

## 说明

公共镜像和 hosts IP 都由第三方维护，可用性会变化。工具只做测速与选择，不保证任何镜像的长期稳定或安全；下载重要文件后建议核对官方 SHA256。
