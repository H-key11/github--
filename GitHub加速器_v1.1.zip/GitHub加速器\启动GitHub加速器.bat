@echo off
setlocal
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
    echo [ERROR] Windows PowerShell 5.1 not found.
    pause
    exit /b 1
)

if not exist "%~dp0app.ps1" (
    echo [ERROR] app.ps1 not found next to this launcher.
    pause
    exit /b 1
)

start "" "%PS%" -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0app.ps1"
endlocal
